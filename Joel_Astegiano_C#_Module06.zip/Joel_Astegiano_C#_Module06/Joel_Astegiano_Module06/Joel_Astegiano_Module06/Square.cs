﻿namespace Joel_Astegiano_Module06
{
    class Square : Rectangle
    {

    }
  
}
